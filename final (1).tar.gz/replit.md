# Perfect Pressure Power Washing - Replit Configuration

## Overview

This is a full-stack web application for Perfect Pressure Power Washing, a professional cleaning service company based in Bentonville, Rogers, Little Flock, Bella Vista and surrounding areas. The application features a modern React frontend with TypeScript, a Node.js/Express backend, and uses PostgreSQL with Drizzle ORM for data management.

## User Preferences

Preferred communication style: Simple, everyday language.

## Contact Information

- Phone: (479) 399-8717
- Email: perfectpreasure@gmail.com
- Service Areas: Bentonville, Rogers, Little Flock, Bella Vista & Surrounding Areas

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui components
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL (configured for Neon Database)
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **API Style**: REST API with JSON responses
- **Development**: Hot reload with Vite middleware integration

## Key Components

### Database Schema
The application uses a PostgreSQL database with the following main tables:
- `users`: User authentication and management
- `quotes`: Customer quote requests with status tracking
- `blog_posts`: CMS for blog content with featured posts
- `faqs`: Frequently asked questions management
- `service_areas`: Geographic service area definitions
- `contacts`: Contact form submissions
- `gallery_images`: Before/after image gallery

### API Endpoints
- `POST /api/quotes` - Create new quote requests
- `GET /api/quotes` - Retrieve quote requests
- `POST /api/contacts` - Handle contact form submissions
- `GET /api/contacts` - Retrieve contact submissions
- Additional endpoints for blog posts, FAQs, service areas, and gallery

### Frontend Pages
- **Home**: Landing page with hero section, services, team info, and contact forms
- **Services**: Detailed service descriptions and pricing
- **Cost Calculator**: Interactive pricing calculator for estimates
- **Blog**: Blog posts and company news
- **404**: Custom not found page

## Data Flow

1. **User Interaction**: Users interact with React components that use React Hook Form for input validation
2. **API Communication**: TanStack Query manages API calls with automatic caching and error handling
3. **Server Processing**: Express routes handle requests, validate data with Zod schemas, and interact with the database
4. **Database Operations**: Drizzle ORM provides type-safe database operations with PostgreSQL
5. **Response Handling**: JSON responses are processed by the frontend with toast notifications for user feedback

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with PostCSS
- **Icons**: Lucide React icons
- **Date Handling**: date-fns for date utilities
- **Build Tools**: Vite with React plugin

### Backend Dependencies
- **Database**: Neon Database (PostgreSQL)
- **ORM**: Drizzle ORM with PostgreSQL driver
- **Validation**: Zod for schema validation
- **Session Management**: connect-pg-simple for PostgreSQL sessions

### Development Tools
- **TypeScript**: Full TypeScript support across the stack
- **ESLint**: Code linting and formatting
- **Replit Integration**: Vite plugin for Replit development environment

## Deployment Strategy

### Development Environment
- **Local Development**: `npm run dev` starts the Express server with Vite middleware
- **Hot Reload**: Vite provides instant updates for frontend changes
- **Database**: Uses DATABASE_URL environment variable for PostgreSQL connection

### Production Build
- **Frontend Build**: `vite build` creates optimized static assets
- **Backend Build**: `esbuild` bundles the server code for production
- **Static Serving**: Express serves built frontend assets in production
- **Database Migrations**: Drizzle Kit manages database schema migrations

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **NODE_ENV**: Environment mode (development/production)
- **Session Configuration**: PostgreSQL-backed sessions for user management

The application is designed for easy deployment on platforms like Replit, Vercel, or any Node.js hosting service with PostgreSQL support.

## Recent Changes

### January 16, 2025
- **Major Database Migration**: Switched from in-memory storage to persistent PostgreSQL database
- **Enhanced Admin Dashboard**: Added comprehensive customization features:
  - Complete image asset management with categories (homepage, services, branding, gallery, blog)
  - Color theme management with live preview and category organization
  - Promo code system with expiration dates, usage limits, and discount validation
  - Service pricing controls with per-square-foot calculations and story multipliers
  - Site settings management with real-time updates
- **Fixed React Hooks Error**: Resolved white screen issue in admin panel by properly ordering hooks
- **Real-time Updates**: Implemented WebSocket connections for instant admin changes
- **Data Persistence**: All changes now save permanently to PostgreSQL database
- **Default Data Initialization**: Auto-populates database with sample content on first run
- **Enhanced Cost Calculator**: Added promo code support with real-time discount calculations
- **Secure Admin Access**: Protected admin panel with access code "admin2025"
- **Contact Information**: Updated throughout site (Phone: 479-399-8717, Email: perfectpreasure@gmail.com)
- **Complete Branding Overhaul**: Changed all "Eco Clean" references to "Perfect Pressure" throughout the entire website
- **New Logo Implementation**: Updated main logo with Perfect Pressure branding (uploaded 1024x1024px logo)
- **Hero Background**: Added professional power washing services background image
- **Service Area Updates**: Changed from Harrisburg/Mechanicsburg to Bentonville/Rogers/Little Flock/Bella Vista
- **Pricing Updates**: Driveway $0.10 per sq ft, Roof $0.40 per sq ft
- **Removed Team Section**: "Meet the Eco Clean Team" section completely removed from homepage
- **FAQ Updates**: Updated plant safety answer, removed window/trim from house washing, removed licensing/insurance FAQ
- **Cost Calculator**: Removed additional services section for cleaner interface
- **Visual Page Builder**: Added Shopify-style drag-and-drop page builder with:
  - Drag-and-drop section reordering
  - Inline text editing with visual feedback
  - Real-time preview with desktop/mobile views
  - Component library with hero, text, image, services, contact, and testimonial sections
  - Visual style editor with colors, spacing, and typography controls
  - Live background image management
  - Section visibility toggles
  - Accessible via prominent button in admin dashboard
  - **Image Upload Integration**: Direct file upload for hero backgrounds and image sections
    - Drag & drop file upload with instant preview
    - Real-time upload progress indicators
    - Automatic image optimization and database storage
    - One-click image removal with fallback to placeholders
- **Enhanced Image System**: Connected database images to website display with real-time updates

### January 23, 2025
- **GitHub Deployment Ready**: Created comprehensive deployment configuration for GitHub hosting
  - GitHub Actions workflow for automated deployment to GitHub Pages
  - Production Vite configuration optimized for static hosting
  - Detailed deployment guide with multiple hosting options (GitHub Pages, Heroku, Railway, Render)
  - README with project overview and quick start instructions
  - Support for both static frontend-only and full-stack deployment approaches
- **Service Images Complete**: All four professional service images uploaded and active:
  - Pressure washing: Surface cleaner equipment in action
  - House washing: Cleaning house siding demonstration  
  - Roof cleaning: Clean shingle roof results
  - Gutter cleaning: Clogged gutters showing service need
- **Social Media Integration**: Updated footer with actual Facebook and TikTok links
- **Admin Panel Security**: Completely hidden from public navigation, accessible only via ADMIN2025 promo code