# Perfect Pressure Power Washing - Full Implementation

A complete, professional website for Perfect Pressure Power Washing services.

## Features

### Frontend
- Modern React with TypeScript
- Professional Perfect Pressure branding
- Responsive design with Tailwind CSS
- Cost calculator with real-time pricing
- Contact and quote forms
- Gallery system
- Professional navigation and footer

### Backend
- Express.js API server
- PostgreSQL database with Drizzle ORM
- Real-time WebSocket updates
- Secure admin dashboard
- File upload capabilities

### Admin Dashboard
- Access with code: ADMIN2025 (enter in cost calculator)
- Promo code management
- Image asset management
- Real-time site customization

## Business Information
- Phone: (479) 399-8717
- Email: perfectpreasure@gmail.com
- Service Areas: Bentonville, Rogers, Little Flock, Bella Vista & Surrounding Areas

## Services Offered
1. **Pressure Washing** - $0.10 per sq ft for driveways, sidewalks, hard surfaces
2. **House Washing** - Starting $200+ for soft washing exterior siding
3. **Gutter Cleaning** - Starting $100+ for complete gutter maintenance

## Quick Start

1. Install dependencies:
   ```bash
   npm install
   ```

2. Set up environment variables:
   ```bash
   # Create .env file with:
   DATABASE_URL=your_postgresql_url
   NODE_ENV=development
   ```

3. Push database schema:
   ```bash
   npm run db:push
   ```

4. Start development server:
   ```bash
   npm run dev
   ```

5. Open http://localhost:5000

## Deployment

The application is ready for deployment on platforms like:
- Replit
- Vercel (with PostgreSQL addon)
- Railway
- Heroku
- DigitalOcean App Platform

## Admin Access

Visit the cost calculator page and enter promo code "ADMIN2025" to unlock admin features, or visit /admin directly after unlocking.

## Database

The application uses PostgreSQL with the following main tables:
- Users, quotes, contacts
- Blog posts, FAQs, service areas
- Gallery images, site settings
- Service pricing, promo codes
- Image assets, color themes

All data persists between sessions and supports real-time updates.